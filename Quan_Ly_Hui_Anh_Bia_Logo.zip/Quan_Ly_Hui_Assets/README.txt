BO FILE ANH BIA VA LOGO - QUAN LY HUI

Trong thu muc nay co:
- index.html: trang app da them anh bia va logo icon.
- assets/anh-bia-quan-ly-hui.png: anh bia dau trang.
- assets/logo-quan-ly-hui.png: logo/favicon va icon iPhone.

CACH CAP NHAT GITHUB (tren iPhone):
1. Mo repo Quan-li-hui-pro tren GitHub.
2. Xoa file index.html cu hoac mo file index.html de thay noi dung.
3. Tai len file index.html trong bo nay va commit vao nhanh main.
4. Tai len ca thu muc assets (gom 2 anh) vao thu muc goc repo, giu dung ten va duong dan assets/...
5. Doi 1-3 phut, mo lai https://trunghaupro90-max.github.io/Quan-li-hui-pro/ va bam tai lai.

Luu y: Khong xoa/cap nhat cac thiet lap Supabase trong trang app. File index.html nay giu nguyen phan dang nhap va quan ly du lieu cua ban; chi thay phan dau trang va them lien ket logo.
